﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using KoiShop.Repositories.Entities;

namespace KoiShop.Webapplication.Pages.FishPage
{
    public class CreateModel : PageModel
    {
        private readonly KoiShop.Repositories.Entities.KoiShopContext _context;

        public CreateModel(KoiShop.Repositories.Entities.KoiShopContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["IdCategory"] = new SelectList(_context.KoiFishCategories, "Id", "Name");
            return Page();
        }

        [BindProperty]
        public Fish Fish { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Fish.Add(Fish);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
