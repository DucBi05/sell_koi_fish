﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiShop.Repositories.Entities;

namespace KoiShop.Webapplication.Pages.FishPage
{
    public class DetailsModel : PageModel
    {
        private readonly KoiShop.Repositories.Entities.KoiShopContext _context;

        public DetailsModel(KoiShop.Repositories.Entities.KoiShopContext context)
        {
            _context = context;
        }

        public Fish Fish { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fish = await _context.Fish.FirstOrDefaultAsync(m => m.KoiId == id);
            if (fish == null)
            {
                return NotFound();
            }
            else
            {
                Fish = fish;
            }
            return Page();
        }
    }
}
