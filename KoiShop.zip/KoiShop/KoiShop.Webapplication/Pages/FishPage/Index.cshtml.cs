﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using KoiShop.Repositories.Entities;
using KoiShop.Services.Interface;

namespace KoiShop.Webapplication.Pages.FishPage
{
    public class IndexModel : PageModel
    {
        private readonly IFishService _fishService;

        public IndexModel(IFishService fishService)
        {
            _fishService = fishService;
        }

        public IList<Fish> Fish { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Fish = await _fishService.GetFishList();
        }
    }
}
